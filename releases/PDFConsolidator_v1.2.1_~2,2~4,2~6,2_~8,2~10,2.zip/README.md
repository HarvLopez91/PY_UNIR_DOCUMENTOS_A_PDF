# PDF Consolidator - Aplicación de Usuario

## Instrucciones de Uso

1. Ejecute `PDFConsolidator.exe`
2. Coloque sus documentos en la carpeta `data\input\`
3. Complete los campos: Identificación, Cliente, Reembolso
4. Haga clic en "Consolidar PDF"
5. El archivo resultante estará en `data\output\`

## Formatos Soportados
- PDF, Word (.doc/.docx), Excel (.xlsx), Imágenes (.jpg/.png/.tif)

## Soporte
- Contacto: edwin.clavijo@laascension.com

## Versión
- Aplicación: PDF Consolidator v1.2.1
- Empresa: La Ascensión S.A.
- Fecha: jue 30/10/2025
